package com.example.track_e

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var stepCount: TextView

    private val trackingLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (result.resultCode == RESULT_OK) {

                val steps = result.data?.getIntExtra(
                    "steps",
                    0
                ) ?: 0

                val distance = result.data?.getFloatExtra(
                    "distance",
                    0f
                ) ?: 0f

                // Add this session's steps to today's total
                val todaySteps =
                    getTodaySteps() + steps

                saveTodaySteps(todaySteps)

                stepCount.text =
                    todaySteps.toString()

                // Keep saving the individual session to history
                saveHistory(steps, distance)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        stepCount =
            findViewById(R.id.stepCount)

        val startButton =
            findViewById<Button>(R.id.startButton)

        val historyButton =
            findViewById<Button>(R.id.historyButton)

        // Load today's steps when the app opens
        stepCount.text =
            getTodaySteps().toString()

        startButton.setOnClickListener {

            val intent =
                Intent(this, TrackingActivity::class.java)

            trackingLauncher.launch(intent)
        }

        historyButton.setOnClickListener {

            val intent =
                Intent(this, HistoryActivity::class.java)

            startActivity(intent)
        }
    }

    private fun getTodaySteps(): Int {

        val preferences =
            getSharedPreferences(
                "track_e_history",
                MODE_PRIVATE
            )

        val savedDate =
            preferences.getString(
                "today_date",
                ""
            )

        val today =
            SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.getDefault()
            ).format(Date())

        // New day → reset today's steps
        if (savedDate != today) {

            preferences.edit()
                .putString("today_date", today)
                .putInt("today_steps", 0)
                .apply()

            return 0
        }

        return preferences.getInt(
            "today_steps",
            0
        )
    }

    private fun saveTodaySteps(steps: Int) {

        val preferences =
            getSharedPreferences(
                "track_e_history",
                MODE_PRIVATE
            )

        val today =
            SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.getDefault()
            ).format(Date())

        preferences.edit()
            .putString("today_date", today)
            .putInt("today_steps", steps)
            .apply()
    }

    private fun saveHistory(
        steps: Int,
        distance: Float
    ) {

        val preferences =
            getSharedPreferences(
                "track_e_history",
                MODE_PRIVATE
            )

        val oldHistory =
            preferences.getString(
                "history",
                ""
            ) ?: ""

        val date =
            SimpleDateFormat(
                "dd MMM yyyy, HH:mm",
                Locale.getDefault()
            ).format(Date())

        val newEntry =
            "$date|$steps|$distance"

        val newHistory =
            if (oldHistory.isEmpty()) {
                newEntry
            } else {
                "$newEntry;$oldHistory"
            }

        preferences.edit()
            .putString(
                "history",
                newHistory
            )
            .apply()
    }
}