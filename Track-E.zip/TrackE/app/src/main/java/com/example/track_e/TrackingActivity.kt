package com.example.track_e

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlin.math.abs
import kotlin.math.sqrt

class TrackingActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null

    private lateinit var sensorValue: TextView
    private lateinit var locationValue: TextView
    private lateinit var distanceValue: TextView
    private lateinit var activityStatus: TextView

    private lateinit var fusedLocationClient:
            FusedLocationProviderClient

    private lateinit var locationCallback: LocationCallback

    private var currentMovement = 0f

    private var stepCount = 0

    private var lastMovement = 0f
    private var lastStepTime = 0L

    private var totalDistance = 0f
    private var lastLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_tracking)

        // Each TrackingActivity instance represents one new GPS session.
        totalDistance = 0f
        lastLocation = null

        sensorValue =
            findViewById(R.id.sensorValue)

        locationValue =
            findViewById(R.id.locationValue)

        distanceValue =
            findViewById(R.id.distanceValue)

        activityStatus =
            findViewById(R.id.activityStatus)

        val stopButton =
            findViewById<Button>(R.id.stopButton)

        // Accelerometer
        sensorManager =
            getSystemService(SENSOR_SERVICE)
                    as SensorManager

        accelerometer =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER
            )

        // GPS

        fusedLocationClient =
            LocationServices
                .getFusedLocationProviderClient(this)

        locationCallback =
            object : LocationCallback() {

                override fun onLocationResult(
                    result: LocationResult
                ) {

                    for (location in result.locations) {

                        processLocation(location)
                    }
                }
            }

        startLocationUpdates()

        stopButton.setOnClickListener {

            stopLocationUpdates()

            val resultIntent = Intent()

            resultIntent.putExtra(
                "steps",
                stepCount
            )

            resultIntent.putExtra(
                "distance",
                totalDistance
            )

            setResult(
                RESULT_OK,
                resultIntent
            )

            finish()
        }
    }

    private fun startLocationUpdates() {

        if (
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                100
            )

            return
        }

        val locationRequest =
            LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                3000
            )
                .setMinUpdateIntervalMillis(2000)
                .build()

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            mainLooper
        )
    }

    private fun stopLocationUpdates() {

        fusedLocationClient
            .removeLocationUpdates(locationCallback)
    }

    private fun processLocation(location: Location) {

        locationValue.text =
            "Latitude: %.5f\nLongitude: %.5f".format(
                location.latitude,
                location.longitude
            )

        val previousLocation = lastLocation

        if (previousLocation != null) {

            val distance =
                previousLocation.distanceTo(location)

            // Ignoring unrealistic GPS jumps
            if (distance < 100) {

                // distanceTo() returns metres. Value in metres
                // until it is converted for display or history.
                totalDistance += distance

                distanceValue.text =
                    "Distance: %.2f km".format(
                        totalDistance / 1000
                    )
            }
        }

        lastLocation = location
    }

    override fun onResume() {
        super.onResume()

        accelerometer?.let {

            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    override fun onPause() {
        super.onPause()

        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(
        event: SensorEvent?
    ) {

        if (
            event?.sensor?.type ==
            Sensor.TYPE_ACCELEROMETER
        ) {

            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            currentMovement =
                sqrt(
                    x * x +
                            y * y +
                            z * z
                )

            sensorValue.text =
                "Movement: %.2f".format(
                    currentMovement
                )

            val difference =
                abs(
                    currentMovement -
                            lastMovement
                )

            val currentTime =
                System.currentTimeMillis()

            // Step detection
            if (
                difference > 0.5 &&
                difference < 4.0 &&
                currentTime - lastStepTime > 300
            ) {

                stepCount++

                lastStepTime =
                    currentTime

                activityStatus.text =
                    "Steps: $stepCount"
            }

            lastMovement =
                currentMovement
        }
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) {
    }
}
