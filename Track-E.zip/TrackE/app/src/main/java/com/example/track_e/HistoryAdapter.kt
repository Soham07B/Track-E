package com.example.track_e

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistoryAdapter(
    private val records: List<ActivityRecord>
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val date: TextView = itemView.findViewById(R.id.historyDate)
        val steps: TextView = itemView.findViewById(R.id.historySteps)
        val distance: TextView =
            itemView.findViewById(R.id.historyDistance)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HistoryViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)

        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: HistoryViewHolder,
        position: Int
    ) {

        val record = records[position]

        holder.date.text = record.date
        holder.steps.text = "Steps: ${record.steps}"
        holder.distance.text =
            "Distance: %.2f km".format(record.distance/1000)
    }

    override fun getItemCount(): Int {
        return records.size
    }
}