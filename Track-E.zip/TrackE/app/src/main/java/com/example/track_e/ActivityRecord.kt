package com.example.track_e

data class ActivityRecord(
    val date: String,
    val steps: Int,
    val distance: Double
)