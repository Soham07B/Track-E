package com.example.track_e

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class ActivityGraphView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var activityValues = listOf<Float>()

    fun setActivityData(values: List<Float>) {
        activityValues = values
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (activityValues.isEmpty()) {
            return
        }

        paint.strokeWidth = 6f
        paint.style = Paint.Style.STROKE

        val width = width.toFloat()
        val height = height.toFloat()

        val left = 60f
        val right = width - 40f
        val top = 40f
        val bottom = height - 60f

        // X and Y axes
        canvas.drawLine(left, bottom, right, bottom, paint)
        canvas.drawLine(left, top, left, bottom, paint)

        val maxValue =
            activityValues.maxOrNull() ?: 1f

        val spacing =
            if (activityValues.size > 1) {
                (right - left) /
                        (activityValues.size - 1)
            } else {
                0f
            }

        // Draw graph lines
        for (i in 0 until activityValues.size - 1) {

            val x1 =
                left + i * spacing

            val y1 =
                bottom -
                        (activityValues[i] / maxValue) *
                        (bottom - top)

            val x2 =
                left + (i + 1) * spacing

            val y2 =
                bottom -
                        (activityValues[i + 1] / maxValue) *
                        (bottom - top)

            canvas.drawLine(
                x1,
                y1,
                x2,
                y2,
                paint
            )
        }

        // Draw points
        paint.style = Paint.Style.FILL

        for (i in activityValues.indices) {

            val x =
                left + i * spacing

            val y =
                bottom -
                        (activityValues[i] / maxValue) *
                        (bottom - top)

            canvas.drawCircle(
                x,
                y,
                8f,
                paint
            )
        }
    }
}