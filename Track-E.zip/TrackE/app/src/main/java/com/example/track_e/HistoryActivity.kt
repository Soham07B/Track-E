package com.example.track_e

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_history)

        val recyclerView =
            findViewById<RecyclerView>(
                R.id.historyRecyclerView
            )

        val records = loadHistory()

        recyclerView.adapter =
            HistoryAdapter(records)

        val graph =
            findViewById<ActivityGraphView>(
                R.id.activityGraph
            )

        val graphValues =
            records
                .reversed()
                .map { it.steps.toFloat() }

        graph.setActivityData(graphValues)
    }

    private fun loadHistory(): List<ActivityRecord> {

        val preferences =
            getSharedPreferences(
                "track_e_history",
                MODE_PRIVATE
            )

        val history =
            preferences.getString(
                "history",
                ""
            ) ?: ""

        if (history.isEmpty()) {
            return emptyList()
        }

        val records =
            mutableListOf<ActivityRecord>()

        val entries =
            history.split(";")

        for (entry in entries) {

            val parts =
                entry.split("|")

            if (parts.size == 3) {

                val date = parts[0]

                val steps =
                    parts[1].toIntOrNull() ?: 0

                val distance =
                    parts[2].toDoubleOrNull() ?: 0.0

                records.add(
                    ActivityRecord(
                        date,
                        steps,
                        distance
                    )
                )
            }
        }

        return records
    }
}